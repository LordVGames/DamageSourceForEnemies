## 1.2.0

- Changed the config options' section name
- - Probably means the config options have been reset so double check them if you changed any
- Fixed FlatItemBuff's squid polyp edit breaking this mod's squid polyp edit
- Added a DamageSource to the scorch wurm shot's damage zone
- - This also configurable just like the other damage zones (this one is on by default)


## 1.1.0

- Fixed for SOTS phase 2

- Gave the flamethrower drone the correct DamageSource
- - It was basing itself off of Artificer's, so it had the "Special" DamageSource before this. Now it has the "Primary" DamageSource as it should.

- Added a few config options for some enemies' ground damage zones getting a DamageSource
- - Mini Mushrum's spore attack (on by default)
- - Beetle Queen's spit attack (off by default)
- - Voidling's one attack that leaves a big damage zone (off by default)

## 1.0.0

- First release