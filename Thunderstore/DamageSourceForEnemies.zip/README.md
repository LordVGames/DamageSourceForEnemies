# R2Boilerplate

This repository contains a sample mod for Risk of Rain 2.

You can clone this repository, open the visual studio solution file and compile it immediately.

This repository is meant to represent best practices for starting a simple mod.

Once your mod get compiled, you can utilize the Thunderstore folder for later uploading it to https://thunderstore.io/c/riskofrain2/